import time


def start_story():
    print("Welcome to the land of Redlon!")
    print("You wake at a fork in the road. on the left is a forrest, on the right is a village in the distance.")
    print("Where do you want to go?")
    print("1. Go left into the forest")
    print("2. Go visit the village on the right")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")

    if choice == "1":
        go_to_forest()
    elif choice == "2":
        visit_village()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        start_story()


def go_to_forest():
    print("\nYou head left into the forest. It's quiet. You see a cave and a gigantic tree in a clearing.")
    print("What do you want to do?")
    print("1. Explore the cave")
    print("2. Climb the tree")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")

    if choice == "1":
        explore_cave()
    elif choice == "2":
        climb_tree()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        go_to_forest()


def explore_cave():
    print("\nYou enter the cave. It's dark and damp.")
    print("you see a bear in-front of the treasure looking like its about to attack you.")
    print("What do you do?")
    print("1. run for the treasure pass the bear")
    print("2. Run away from a bear!")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")

    if choice == "1":
        print("\nYou make it to the chest full of treasure!")
        print("However you still have to make it out safely from the bear")
        bear_choice()
    elif choice == "2":
        print("\nYou narrowly escape the cave and return to safety of the forrest.")
        go_to_forest()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        explore_cave()
def bear_choice():
    print("\nYou have two options to escape.")
    print("you can run left or right with your treasure.")
    print("What do you do?")
    print("1. Run right")
    print("2. Run left!")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")
    if choice == "1":
        print("\nThe bear killed you.")
        restart_or_exit()
    elif choice == "2":
        print("\nyou dodge the bear's attack and make it out.")
        print("congratulations, you made it out with your treasure, you win.")
        restart_or_exit()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        bear_choice()
def climb_tree():
    print("\nYou climb the tree. The view is beautiful and you can see the land for miles!")
    print("you notice you are only halfway up the tree. Near you is a birds nest with eggs ")
    print("What do you do?")
    print("1. move closer to check the bird’s nest")
    print("2. Climb higher")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")

    if choice == "1":
        print("\nYou climb over to the nest and inspect the eggs, as you do the branch holding you breaks. !")
        print("you fall to your death")
        restart_or_exit()
    elif choice == "2":
        print("\nYou climb higher; as you do a tree house comes into view and you climb closer.")
        treehouse()

    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        climb_tree()
def treehouse():
    print("/nas you climb closer and then into the tree house you notice gold and silver silverware.")
    print("There is no one home.")
    print("1. Steal goods")
    print("2. Leave tree house")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")
    if choice == "1":
        print("\nyou steal the goods and sell them, you are filthy rich")
        print("congratulations, you win")
        restart_or_exit()
    elif choice == "2":
        print("\nyou leave without anything")
        restart_or_exit()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        treehouse()

def visit_village():
    print("\nYou turn right and arrive at the village bustling with activity. Near you is a smithy and a tavern.")
    print("Where do you want to go?")
    print("1. go to the smithy and talk to the blacksmith")
    print("2. Enter the tavern")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")

    if choice == "1":
        talk_to_blacksmith()
    elif choice == "2":
        enter_tavern()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        visit_village()


def talk_to_blacksmith():
    print("\nThe blacksmith greets you warmly, and gives you a choice")
    print("would you like a sword or would you like to know something about the mountains?")
    print("1. Request a sword")
    print("2. Ask about the mountains")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")

    if choice == "1":
        print("\nThe blacksmith gives you a powerful sword, crafted with the finest most expensive materials.")
        request_payment()
    elif choice == "2":
        print("\nThe blacksmith tells you about a treasure in the mountains.")
        mountain()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        talk_to_blacksmith()
def mountain():
    print("\nYou leave the village and head to the mountain")
    print("As you arrive at the base of the mountain you see two paths")
    print("1. Go left")
    print("2. Go right")
    #left easy path, but you don't make it to the top by nightfall.
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")
    if choice == "1":
        print("\nYou go left")
        hard_path()
    elif choice == "2":
        print("\nYou go right")
        easy_path()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        mountain()
def hard_path():
    print("\nAs you continue up the mountain you notice that the path is unusually hard")
    print("on the way up your path has been blocked multiple times by rock slides and other obstacles making it")
    print("extremely hard to get up. You manage to make it up the mountain before night fall")
    print("1. Make a camp")
    print("2. Search for the treasure now.")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")
    if choice == "1":
        make_camp()
    elif choice == "2":
        search_now()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        hard_path()
def make_camp():
    print("\nYou make a fire and a temporary shelter.")
    print("in the morning you look for the treasure, after a few hours you find it.")
    print("congratulations you win")
    restart_or_exit()
def search_now():
    print("\nYou search in the pitch dark unknowingly creeping closer to the edge.")
    print("You fall of the edge of the mountain side into the dark.")
    restart_or_exit()
def easy_path():
    print("/nAs you walk up the path you notice no obstacles are in your way.")
    print("however as the day moves on you notice that this long easy winding path is too long to make it to the ")
    print("top by night fall. You rush to make it to the top but by the time the sun sets you are not close to the top")
    print("As you are stumbling in the dark you hear a howl as wolfs begin to descend on you.")
    restart_or_exit()
def request_payment():
    print("\nThe blacksmith tells you that you need to pay for the sword. You tell him you have no money")
    print("What are you going to do to pay for it")
    print("1. Work it off")
    print("2. Run away with the sword")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")
    if choice == "1":
        print("\nyou ask him to work it off.")
        work_it_off()
    elif choice == "2":
        print("\nYou run away with the sword.")
        print("You are caught before you make it 20 feet and are thrown in the village jail.")
        restart_or_exit()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        request_payment()
def work_it_off():
    print("\nWhile working off your sword.")
    print("You hear the blacksmith talking to another customer about a treasure in the mountains.")
    print("You could run towards the mountain with out the sword or stay and get your sword after a bit of work")
    #loop to mountain

    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")
    if choice == "1":
        mountain()
    elif choice == "2":
        stay_and_work()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        work_it_off()
def stay_and_work():
    print("\nYou stay and do odd jobs for the blacksmith until you finally work off the sword")
    print("you sell the sword to a passing merchant, you get alot of money for it and you can live happily.")
    print ("\nCongratulations, you win.")
    restart_or_exit()
def enter_tavern():
    print("\nThe tavern is lively and full of people. They are very talkable and easily provoked")
    print("What do you do?")
    print("1. Listen to rumors")
    print("2. start a bar fight")
    choice = input("Enter 1 or 2 (or type 'stop' to exit): ")

    if choice == "1":
        print("\nYou overhear a rumor about treasure in a nearby cave!")
        print("You head into the forrest and find the cave")
        #loops to the cave
        time.sleep(3)
        explore_cave()
    elif choice == "2":
        print("\nYou start a bar fight and are thrown out of the tavern! Try again")
        enter_tavern()
    elif choice.lower() == "stop":
        stop_story()
    else:
        print("Invalid choice. Try again.")
        enter_tavern()


def stop_story():
    print("\nThank you for playing! Goodbye!")
    exit()


def restart_or_exit():
    print("\nWould you like to restart the story or exit?")
    print("1. Restart")
    print("2. Exit")
    choice = input("Enter 1 or 2: ")

    if choice == "1":
        start_story()
    elif choice == "2":
        stop_story()
    else:
        print("Invalid choice. Exiting now.")
        stop_story()


# Start the story
start_story()
