
# Redlon

An interactive program for the introduction to programing FBLA 2024-25 prompt.


## Features

- Fully interactive storyline
- Stop comand functionality
- Decent accessability


## Acknowledgements

 - [Awesome Readme Templates](https://awesomeopensource.com/project/elangosundar/awesome-README-templates)
- Robinson FBLA program
- [pycharm community edition](https://www.jetbrains.com/pycharm/download/?section=windows)
- python 3.13
- This project was developed with assistance from ChatGPT, an AI language model by OpenAI. ChatGPT was used to help generate a template for the code structure.
## Authors

- Pete Caputo
## Appendix

chat gpt cite maybe